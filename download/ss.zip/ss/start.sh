#!/bin/sh

clear
echo "#############################################################"
echo "# Start Shadowsocks for Miwifi"
echo "#############################################################"

# Make sure only root can run our script
if [[ $EUID -ne 0 ]]; then
   echo "Error:This script must be run as root!" 1>&2
   exit 1
fi


# Config shadowsocks init script
cp config/myshadowsocks /etc/init.d/myshadowsocks
chmod +x /etc/init.d/myshadowsocks

#config dnsmasq
mkdir -p /etc/dnsmasq.d
cp -f config/dnsmasq_list.conf /etc/dnsmasq.d/dnsmasq_list.conf

#config firewall
cp -f /etc/firewall.user /etc/firewall.user.back
echo "ipset -N gfwlist iphash -! " >> /etc/firewall.user
echo "iptables -t nat -A PREROUTING -p tcp -m set --match-set gfwlist dst -j REDIRECT --to-port 1081" >> /etc/firewall.user

#restart all service
/etc/init.d/dnsmasq restart
/etc/init.d/firewall restart
/etc/init.d/myshadowsocks start
/etc/init.d/myshadowsocks enable

echo ""
echo "Shadowsocks start success."
echo ""
exit 0
